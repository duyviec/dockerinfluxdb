/**
 * Copyright (C) 2013, PointClickCare
 * Author: Duy Viec
 */
package vn.com.tma.StatsdJava;

import java.io.IOException;
import java.net.UnknownHostException;

import com.timgroup.statsd.NonBlockingStatsDClient;
import com.timgroup.statsd.StatsDClient;
import com.timgroup.statsd.NoOpStatsDClient;

/**
 * @author vlmduy
 * 
 */
public class StatsdClientSample
{
    private static final StatsDClient statsd = new NonBlockingStatsDClient("my.test.1", "localhost", 8125);
    private static final NoOpStatsDClient statsd1 = new NoOpStatsDClient();

    public static final void main(String[] args)
    {
        try
        {
            TestStatsdClient obj = new TestStatsdClient("localhost", 8125);
			for(int i = 0;i <= 100; i++){
				obj.increment("my.test.1", 10);
			}
        }
        catch (UnknownHostException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
        statsd1.count("my.test.1", 1000);
        statsd.count("my.test.1", 1000);
        statsd.incrementCounter("my.test.1");
        
        System.out.println("Increase Counter bar");
        statsd.recordGaugeValue("my.test.1", 100);
        System.out.println("Record Gauge Value baz");
        statsd.recordExecutionTime("my.test.1", 25);
        System.out.println("Record ExecutionTime bag: 25");
        statsd.recordSetEvent("my.test.1", "one");
        System.out.println("Record Set Event qux one");
    }

}
